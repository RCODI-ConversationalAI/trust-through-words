#!/usr/bin/env python
# coding: utf-8

# In[ ]:


import pandas as pd


# In[31]:


df = pd.DataFrame({'Q7': [1.5,0.7071068,1,2,2],
'Q8': [1.5,0.7071068,1,2,2],
'Q9': [5,1.4142136,4,6,2],
'Q41': [2,0,2,2,2],
'Q42': [2,0,2,2,2],
'Q43': [4,0,4,4,2],
'Q75': [2,1.4142136,1,3,2],
'Q76': [3,2.8284271,1,5,2],
'Q77': [5,0,5,5,2]})


# In[12]:


pip install pingouin


# In[9]:


import pingouin as pg


# In[10]:


import pingouin as pg


# In[32]:


pg.cronbach_alpha(data=df, ci=.99)


# In[ ]:




