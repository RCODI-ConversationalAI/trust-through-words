#!/usr/bin/env python
# coding: utf-8

# In[ ]:


import pandas as pd


# In[25]:


df = pd.DataFrame({'Q18': [7,0,7,7,2],
'Q19': [7,0,7,7,2],
'Q20': [7,0,7,7,2],
'Q52': [6.3333333,0.5773503,6,7,3],
'Q53': [6.3333333,0.5773503,6,7,3],
'Q54': [6.3333333,0.5773503,6,7,3],
'Q86': [6.5,0.7071068,6,7,2],
'Q87': [6.5,0.7071068,6,7,2],
'Q88': [6.5,0.7071068,6,7,2]})


# In[12]:


pip install pingouin


# In[9]:


import pingouin as pg


# In[10]:


import pingouin as pg


# In[26]:


pg.cronbach_alpha(data=df, ci=.99)


# In[ ]:




