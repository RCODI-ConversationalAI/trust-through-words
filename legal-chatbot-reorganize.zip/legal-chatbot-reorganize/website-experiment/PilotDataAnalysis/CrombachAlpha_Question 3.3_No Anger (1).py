#!/usr/bin/env python
# coding: utf-8

# In[ ]:


import pandas as pd


# In[20]:


df = pd.DataFrame({'Q4': [3.5,2.1213203,2,5,2],
'Q5': [5.5,0.7071068,5,6,2],
'Q6': [4,2.8284271,2,6,2],
'Q38': [4,0,4,4,2],
'Q39': [4,0,4,4,2],
'Q40': [4,0,4,4,2],
'Q72': [4.5,0.7071068,4,5,2],
'Q73': [4,0,4,4,2],
'Q74': [4,0,4,4,2]})


# In[12]:


pip install pingouin


# In[9]:


import pingouin as pg


# In[10]:


import pingouin as pg


# In[21]:


pg.cronbach_alpha(data=df, ci=.99)


# In[ ]:




