#!/usr/bin/env python
# coding: utf-8

# In[ ]:


import pandas as pd


# In[27]:


df = pd.DataFrame({'Q1': [6,0,6,6,2],
'Q2': [6.5,0.7071068,6,7,2],
'Q3': [6.5,0.7071068,6,7,2],
'Q35': [7,0,7,7,2],
'Q36': [7,0,7,7,2],
'Q37': [7,0,7,7,2],
'Q69': [6.5,0.7071068,6,7,2],
'Q70': [6.5,0.7071068,6,7,2],
'Q71': [6.5,0.7071068,6,7,2]})


# In[12]:


pip install pingouin


# In[9]:


import pingouin as pg


# In[10]:


import pingouin as pg


# In[28]:


pg.cronbach_alpha(data=df, ci=.99)


# In[ ]:




