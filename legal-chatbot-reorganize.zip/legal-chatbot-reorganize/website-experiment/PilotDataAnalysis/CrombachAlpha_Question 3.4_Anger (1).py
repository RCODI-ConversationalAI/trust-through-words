#!/usr/bin/env python
# coding: utf-8

# In[ ]:


import pandas as pd


# In[29]:


df = pd.DataFrame({'Q24': [1.5,0.7071068,1,2,2],
'Q25': [1.5,0.7071068,1,2,2],
'Q26': [4,1.4142136,3,5,2],
'Q58': [1.3333333,0.5773503,1,2,3],
'Q59': [1.3333333,0.5773503,1,2,3],
'Q60': [1.3333333,0.5773503,1,2,3],
'Q92': [2,1.4142136,1,3,2],
'Q93': [2,1.4142136,1,3,2],
'Q94': [2.5,2.1213203,1,4,2]})


# In[12]:


pip install pingouin


# In[9]:


import pingouin as pg


# In[10]:


import pingouin as pg


# In[30]:


pg.cronbach_alpha(data=df, ci=.99)


# In[ ]:




