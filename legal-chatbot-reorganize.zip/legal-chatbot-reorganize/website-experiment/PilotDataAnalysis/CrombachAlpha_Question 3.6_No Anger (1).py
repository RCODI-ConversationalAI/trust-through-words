#!/usr/bin/env python
# coding: utf-8

# In[ ]:


import pandas as pd


# In[39]:


df = pd.DataFrame({'Q14': [5.5,0.7071068,5,6,2],
'Q15': [4,2.8284271,2,6,2],
'Q16': [4,1.4142136,3,5,2],
'Q17': [4.5,0.7071068,4,5,2],
'Q48': [2,0,2,2,2],
'Q49': [2,0,2,2,2],
'Q50': [2,0,2,2,2],
'Q51': [2,0,2,2,2],
'Q82': [4,1.4142136,3,5,2],
'Q83': [5,0,5,5,2],
'Q84': [3.5,0.7071068,3,4,2],
'Q85': [5,0,5,5,2]})


# In[12]:


pip install pingouin


# In[9]:


import pingouin as pg


# In[10]:


import pingouin as pg


# In[40]:


pg.cronbach_alpha(data=df, ci=.99)


# In[ ]:




