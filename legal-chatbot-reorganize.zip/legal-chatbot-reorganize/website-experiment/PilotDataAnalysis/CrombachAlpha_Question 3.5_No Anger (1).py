#!/usr/bin/env python
# coding: utf-8

# In[ ]:


import pandas as pd


# In[35]:


df = pd.DataFrame({'Q10': [5.5,0.7071068,5,6,2],
'Q11': [6,0,6,6,2],
'Q12': [6,0,6,6,2],
'Q13': [6,0,6,6,2],
'Q44': [4.5,0.7071068,4,5,2],
'Q45': [4.5,0.7071068,4,5,2],
'Q46': [4.5,0.7071068,4,5,2],
'Q47': [4.5,0.7071068,4,5,2],
'Q78': [5.5,0.7071068,5,6,2],
'Q79': [5.5,0.7071068,5,6,2],
'Q80': [5,1.4142136,4,6,2],
'Q81': [5.5,0.7071068,5,6,2]})


# In[12]:


pip install pingouin


# In[9]:


import pingouin as pg


# In[10]:


import pingouin as pg


# In[36]:


pg.cronbach_alpha(data=df, ci=.99)


# In[ ]:




