#!/usr/bin/env python
# coding: utf-8

# In[ ]:


import pandas as pd


# In[17]:


df = pd.DataFrame({'Q21': [5,1.4142136,4,6,2],
'Q22': [5,1.4142136,4,6,2],
'Q23': [5,1.4142136,4,6,2],
'Q55': [4,2,2,6,3],
'Q56': [4,1.7320508,2,5,3],
'Q57': [3.6666667,1.5275252,2,5,3],
'Q89': [5,1.4142136,4,6,2],
'Q90': [5,1.4142136,4,6,2],
'Q91': [4,1.4142136,3,5,2]})


# In[12]:


pip install pingouin


# In[9]:


import pingouin as pg


# In[10]:


import pingouin as pg


# In[19]:


pg.cronbach_alpha(data=df, ci=.99)


# In[ ]:




