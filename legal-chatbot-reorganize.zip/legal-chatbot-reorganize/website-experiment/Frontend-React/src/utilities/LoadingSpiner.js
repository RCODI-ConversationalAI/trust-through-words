import "./loadingSpiner.css";

const LoadingSpiner = () => {
    return (
        <div class="lds-facebook"><div></div><div></div><div></div></div>);
};

export default LoadingSpiner;
