### Thank you for completing the legal task.

You will now take a second survey to evaluate your experiences using the online help. Please click on the **Continue** button below to access it.
