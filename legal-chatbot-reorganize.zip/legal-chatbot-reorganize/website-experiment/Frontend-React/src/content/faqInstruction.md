# Self-Help: Tenants' Rights

### Given the scenario, please use the FAQ below to determine how to answer the two following questions:

1. Based on the scenario in the upper right hand corner, are you entitled to the return of all or some of your security deposit from your landlord?
2. If so, what do you need to do to get your security deposit back?
