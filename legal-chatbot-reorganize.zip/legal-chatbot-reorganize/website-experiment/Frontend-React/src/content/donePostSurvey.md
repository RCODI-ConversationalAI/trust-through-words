### Thank you for participating in this experiment. Your response has been recorded.

Thank you for completing the survey. You are now eligible to receive the remuneration of $8.75 for your participation in this study. We will send the approval for payment to Sona promptly. Your contribution to this research will have a significant impact on the quality of AI-based services in the future. We will use the findings from this research to advance the legal chatbot design you used so that it can be used to broaden the access to legal services. You may now close the page. 
