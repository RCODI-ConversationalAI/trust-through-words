### Read the following carefully and envision yourself in this situation as much as you can.

People who do not know their rights as tenants can end up with bad outcomes. 

Imagine that you have lived in an apartment with your spouse and young child for two years.

Your family is quiet and you pay your rent on time.

In late January, when it is particularly cold, the heat in your apartment stops working correctly. 

The temperature in your apartment goes down to 60 degrees at night. 

You call your landlord, **BUT HE REFUSES TO FIX THE PROBLEM!** 

Your stomach tightens and you feel upset thinking about your landlord’s callousness. 

The next day, you call your landlord again and demand that he fix the problem or you will stop paying rent. 

**YOUR LANDLORD HANGS UP THE PHONE ON YOU! WHAT A JERK!!!**

The next day when you return home from work you find a notice on the door saying that YOUR RENT IS INCREASING BY $500 PER MONTH EFFECTIVE IMMEDIATELY. **YOU DON’T HAVE ANOTHER $500 PER MONTH!!!**

Your face, body, and muscles become tense with **ANGER TOWARDS YOUR LANDLORD**, and your breathing quickens.

#### Click "Next" if you are ready to receive your upcoming legal task. The information above is not part of the upcoming scenario.
