import "./App.css";
import React from "react";
import { Route, Routes, BrowserRouter } from "react-router-dom";
import Index from "./component/Index";
import NotFound from "./component/NotFound";
import DonePreSurvey from "./component/DonePreSurvey";
import Login from "./component/Login";
import DoneChatBot from "./component/DoneChatBot";
import DonePostSurvey from "./component/DonePostSurvey";
import FaqPage from "./component/FaqPage";
import theme from "./theme.js";
import { ThemeProvider } from "@mui/material/styles";
import { useUserState, logout } from "./utilities/firebase";
import Loading from "./utilities/Loading";
import NavBar from "./component/NavBar";
function App() {
  const user = useUserState();

  if (user === undefined) {
    return <Loading />;
  }
  return (
    <ThemeProvider theme={theme}>
      {user == null ? (
        <Login />
      ) : (
        <>
          <BrowserRouter>
            <NavBar experimentId={user.uid} />
            <Routes>
              <Route
                exact
                path="/"
                element={<Index user={user} />}
              />
              <Route
                exact
                path="/donePreSurvey"
                element={<DonePreSurvey user={user} />}
              />
              <Route
                exact
                path="/doneChatBot"
                element={<DoneChatBot experimentId={user.uid} />}
              />
              <Route
                exact
                path="/donePostSurvey"
                element={<DonePostSurvey experimentId={user.uid} />}
              />
              <Route exact path="/faq" element={<FaqPage />} />
              <Route path="*" element={<NotFound />} status={404} />
            </Routes>
          </BrowserRouter>
          <div className="experimentId">
            {/* <p>{"[EXTERNAL TESTING]"}</p> */}
            <p>ID: {user.uid} </p>
            <p onClick={logout}>Logout</p>
          </div>
        </>
      )}
    </ThemeProvider>
  );
}

export default App;
