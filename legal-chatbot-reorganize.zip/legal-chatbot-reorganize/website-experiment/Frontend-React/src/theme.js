import { createTheme } from "@mui/material/styles";

const font = "'Helvetica Neue', sans-serif";

const theme = createTheme({
  root: {
    color: "#f0f2f5",
  },
  palette: {
    primary: { main: "#F1F2F9", contrastText: "#000000"},
    blackBtn: { main: "#000000", contrastText: "#ffffff" },
  },
  typography: {
    fontFamily: font,
    fontSize: 14,
    button: {
      textTransform: "none",
    },
  },
  breakpoints: {
    values: {
      xs: 0,
      sm: 600,
      md: 975,
      lg: 1250,
      xl: 1920,
    },
  },
});

export default theme;
